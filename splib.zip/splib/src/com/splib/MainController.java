/* ========================================================================
 * Copyright 2013 Jimmy Halim
 * Licensed under the Creative Commons Attribution-NonCommercial 3.0 license 
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://creativecommons.org/licenses/by-nc/3.0/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
 */
package com.splib;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.FaceDetector;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup.LayoutParams;

import com.jwork.spycamera.utility.LogUtility;

/**
 * @author Jimmy Halim
 */
public class MainController implements PreviewCallback, AutoFocusCallback
	, PictureCallback, ShutterCallback, Serializable {

	private static final long serialVersionUID = 4120558915025481125L;

	public static final int STATE_IDLE = 0;
	public static final int STATE_IMAGE_SINGLE = 1;

	private int state = STATE_IDLE;

	private LogUtility log;
	private Activity activity;
	private Camera camera;
	private SurfaceHolder shPreview;

	private boolean isHolderReady = false;
	private boolean isCameraConfigure = false;	
	private int cameraId;	
	private long lastStartAutofocus = 0;
	private long avgAutofocusTime = -1;
	private boolean crashReport = false;
	private int defaultOrientation;	
	private Parameters cameraParameters;
	private byte[] bSnapShot;
	private Camera.Size previewSize;
	
	private boolean isTakingPicture = false;
	private SurfaceView svPreview;

	private boolean widgetAction = false;	
	private boolean ScreenPrivacy = true;	
	
	public MainController(Activity activity) {
		this.activity = activity;		
		this.log = LogUtility.getInstance();
	}

	public void initData(SurfaceView svPreview) {
		log.v(this,"initData()");
		this.svPreview = svPreview;
		setPreviewImage(1, 1);
	}

	private void setPreviewImage(int width, int height) {
		log.v(this, "setPreviewImage(width:"+width+",height:"+height+")");		
		LayoutParams params = svPreview.getLayoutParams();
		params.width = width;
		params.height = height;		
		svPreview.setLayoutParams(params);
		svPreview.invalidate();
	}
	
	@SuppressLint("NewApi")
	public void startCamera(SurfaceView svPreview) {
		log.v(this,"startCamera()");
		this.svPreview = svPreview;
		if (!crashReport) {
			cameraId = 1; // front camera
			try {				
				camera = Camera.open(cameraId);				
				cameraParameters = camera.getParameters();
				previewSize = camera.new Size(320, 240);				
				
				refreshImagePreviewSize();				
				
				if (shPreview!=null) {
					try {
						camera.setPreviewDisplay(shPreview);						
					} catch (IOException e) {
						log.w(this, e);
					}
				}
				
			} catch (RuntimeException re) {
				log.w(this, re);
				throw re;
			}

			if (isCameraConfigure) {
				startCameraPreview(shPreview);
			} else if (isHolderReady) {
				configureCamera(shPreview);
			}
		}
	}

	private void refreshImagePreviewSize() {
		setPreviewImage(320, 240);
		camera.setDisplayOrientation(90);
	}

	public synchronized void configureCamera(SurfaceHolder holder) {
		log.v(this,"configureCamera()");
		isHolderReady = true;
		shPreview = holder;
		if (camera==null) {
			log.w(this, "configureCamera: camera is null");
			return;
		}
		if (!isCameraConfigure) {
			log.i(this, "previewSize.width : " + previewSize.width + "x" + previewSize.height);

			cameraParameters.setPreviewSize(previewSize.width, previewSize.height);
			cameraParameters.setPreviewFormat(ImageFormat.NV21);
			if (cameraParameters.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO))
			{
				cameraParameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
			} else {
				log.d(this, "Focus mode auto not supported : " + Arrays.toString(cameraParameters.getSupportedFocusModes().toArray()));
			}
			camera.setParameters(cameraParameters);

			startCameraPreview(shPreview);
			isCameraConfigure = true;
		} else {
			log.w(this, "Camera already configured");
			refreshImagePreviewSize();						
		}
	}

	public void startCameraPreview(SurfaceHolder holder) {
		log.v(this,"startCameraPreview()");
		try {
			log.i(this, "Starting preview");
			camera.setPreviewDisplay(holder);
			camera.startPreview();			
			camera.setPreviewCallback(this);
		} catch (IOException e) {
			log.e(this, e);
		} catch (RuntimeException re) {
			throw re;			
		}
	}

	public void stopCamera() {
		log.v(this,"stopCamera()");
		try {
			camera.cancelAutoFocus();
		} catch (Throwable e){
		}
		try {
			camera.setPreviewCallback(null);
		} catch (Throwable e){
		}
		try {
			camera.release();
			camera = null;
		} catch (Throwable e) {
			log.w(this, e);
		}
		isCameraConfigure = false;
		setState(STATE_IDLE);		
	}
	
	public void imageCapture() {
		log.v(this, "imageCapture()");
		if (state==STATE_IDLE) {
			setState(STATE_IMAGE_SINGLE);
			startAutoFocus();
		}
	}

	private void startAutoFocus() {
		log.v(this, "startAutoFocus()");
		if (isCameraConfigure) {
			lastStartAutofocus = System.currentTimeMillis();			
			onAutoFocus(true, camera);			
		} else {
			log.w(this, "Camera is not configured, cannot startAutoFocus");
		}
	}

	@Override
	public void onPreviewFrame(byte[] data, Camera camera) {
		//		log.v(this, "onPreviewFrame()");
		bSnapShot = data;
	}

	@Override
	public void onAutoFocus(boolean success, Camera camera) {
		log.v(this, "onAutoFocus(success:"+success+")");		
		if (bSnapShot==null) {
			log.w(this, "Image data not found");
			setState(STATE_IDLE);
		} else if (cameraParameters==null) {
			log.w(this, "Image parameter not found");
			setState(STATE_IDLE);
		} else if (bSnapShot!=null) {
			long completeAutofocus = System.currentTimeMillis();
			synchronized (camera) {
				//					log.d(this, "lastCapture : " + lastCapture + "|" + avgAutofocusTime);
				try {
					if (!isTakingPicture) {
						//average autofocus speed
						if (avgAutofocusTime==-1) {
							avgAutofocusTime = completeAutofocus-lastStartAutofocus;
						} else {
							avgAutofocusTime += completeAutofocus-lastStartAutofocus;
							avgAutofocusTime /= 2;
						}
						log.d(this, "Average Focus Time : " + avgAutofocusTime);

						saveImage();						
						//saveImage2(true);
					} else {
						log.w(this, "Ignoring the capture request because still in middle taking picture");
					}

					if (state == STATE_IMAGE_SINGLE) {
						if (isCameraConfigure) {
							try {
								camera.cancelAutoFocus();
							} catch (RuntimeException e){
							}
						}
					}
				} catch (IOException e) {
					log.w(this,e);
					if (isCameraConfigure) {
						try {
							camera.cancelAutoFocus();
						} catch (RuntimeException e2){
						}
					}
				}
			}
		}
	}

	private void saveImage() throws IOException {		
		// Create Image from preview data - byte[]
		// converting to RGB for rotation
		int[] rgbData = null;		
		// USING custom YuvDecoder
		log.d(this, "Using custom YUV decoder");
		Size size = cameraParameters.getPreviewSize();
		rgbData = new int[size.width * size.height];
		decodeYUV(rgbData, bSnapShot, size.width, size.height);
		Bitmap bm = Bitmap.createBitmap(rgbData, size.width, size.height,
				Bitmap.Config.RGB_565);
		
		Matrix m = new Matrix();
		m.setRotate(270, (float) size.width / 2, (float) size.height / 2);
		
		Bitmap bm2 = Bitmap.createBitmap(bm, 0, 0, size.width, size.height, m, false);
		bm.recycle();
		bm = null;
		calculatePrivacy(bm2);
		bm2.recycle();
		bm2 = null;
								
		if (state == STATE_IMAGE_SINGLE) {
			setState(STATE_IDLE);
		}							
	}

	private void calculatePrivacy (Bitmap sourceImage) {
		int MAX_FACES = 10;
        FaceDetector fd;                
        FaceDetector.Face [] faces = new FaceDetector.Face[MAX_FACES];        
        int count = 0;
        try {        	
                fd = new FaceDetector(sourceImage.getWidth(), sourceImage.getHeight(), MAX_FACES);
                count = fd.findFaces(sourceImage, faces);
        } catch (Exception e) {                
        }
        
        if (count == 0 || count > 1) ScreenPrivacy = false;
        else ScreenPrivacy = true;        
	}		
	
	public boolean getSP() {
		return ScreenPrivacy;
	}
	
	private void saveImage2(boolean yuv) throws IOException {
		log.d(this, "Calling saveImage(yuv:"+yuv+")");		
		FileOutputStream filecon = null;
		try { 
			File directory = new File(Environment.getExternalStorageDirectory().getPath() + "/SpyCamera");
			if (!directory.exists()) {
				directory.mkdir();
			}
			File file = new File( directory.getAbsolutePath()+ "/SP.jpg");
			filecon = new FileOutputStream(file);
			
			//Create Image from preview data - byte[]
			// converting to RGB for rotation
			int[] rgbData = null;
			if (yuv) {
				//USING custom YuvDecoder
				log.d(this, "Using custom YUV decoder");
				Size size = cameraParameters.getPreviewSize();
				rgbData = new int[size.width*size.height];
				decodeYUV(rgbData, bSnapShot, size.width, size.height);
				
				Matrix m = new Matrix();
				m.setRotate(270, (float) size.width / 2, (float) size.height / 2);
				
				Bitmap bitmap = Bitmap.createBitmap(rgbData, size.width, size.height, Bitmap.Config.ARGB_8888);
				Bitmap bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, size.width, size.height, m, false);
				
				bitmap.recycle();							
				bitmap2.compress(CompressFormat.JPEG, 100, filecon);
				bitmap2.recycle();
			} else {
				filecon.write(bSnapShot);
				filecon.close();
			}
			
			if (state==STATE_IMAGE_SINGLE) {
				setState(STATE_IDLE);
			}
			
			Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		    Uri contentUri = Uri.fromFile(file);
		    mediaScanIntent.setData(contentUri);
		    activity.sendBroadcast(mediaScanIntent);
			
		} catch (RuntimeException e) {
			log.w(this, e);			
		} finally {
			if (filecon!=null) {
				try {
					filecon.close();
				} catch (IOException e) {}
			}
		}
	}
	
	public void decodeYUV(int[] out, byte[] fg, int width, int height)
			throws NullPointerException, IllegalArgumentException {
		log.v(this, "decodeYUV(out:"+out+"|fg:"+(fg!=null?fg.length:null)+"|w:"+width+"|h:"+height+")");
		int sz = width * height;
		if (out == null)
			throw new NullPointerException("buffer out is null");
		if (out.length < sz)
			throw new IllegalArgumentException("buffer out size " + out.length
					+ " < minimum " + sz);
		if (fg==null)
			throw new NullPointerException("buffer 'fg' is null");

		if (fg.length < sz)
			throw new IllegalArgumentException("buffer fg size " + fg.length
					+ " < minimum " + sz);

		int i, j;
		int Y, Cr = 0, Cb = 0;
		for (j = 0; j < height; j++) {
			int pixPtr = j * width;
			final int jDiv2 = j >> 1;
			for (i = 0; i < width; i++) {
				Y = fg[pixPtr];
				if (Y < 0)
					Y += 255;
				if ((i & 0x1) != 1) {
					final int cOff = sz + jDiv2 * width + (i >> 1) * 2;
					Cb = fg[cOff];
					if (Cb < 0)
						Cb += 127;
					else
						Cb -= 128;
					Cr = fg[cOff + 1];
					if (Cr < 0)
						Cr += 127;
					else
						Cr -= 128;
				}
				int R = Y + Cr + (Cr >> 2) + (Cr >> 3) + (Cr >> 5);
				if (R < 0)
					R = 0;
				else if (R > 255)
					R = 255;
				int G = Y - (Cb >> 2) + (Cb >> 4) + (Cb >> 5) - (Cr >> 1)
						+ (Cr >> 3) + (Cr >> 4) + (Cr >> 5);
				if (G < 0)
					G = 0;
				else if (G > 255)
					G = 255;
				int B = Y + Cb + (Cb >> 1) + (Cb >> 2) + (Cb >> 6);
				if (B < 0)
					B = 0;
				else if (B > 255)
					B = 255;
				out[pixPtr++] = (0xff000000 + (B << 16) + (G << 8) + R);
			}
		}

	}

	@Override
	public void onShutter() {
		log.v(this, "onShutter()");
	}

	@Override
	public void onPictureTaken(byte[] data, Camera camera) {
		log.v(this, "onPictureTaken(data"+(data!=null?data.length:null)+")");
		bSnapShot = data;
		try {
			saveImage2(false);
			camera.startPreview();
			isTakingPicture = false;
		} catch (IOException e) {
			log.w(this, e);
		}
	}
	
	public void setState(int state) {
		log.v(this, "setState(state:"+state+")|widgetAction:"+widgetAction);		
		if (this.widgetAction==true && state==STATE_IDLE) {
			//activity.finish();
		}
		if (state==this.state) {
			return;
		}
		this.state = state;		
	}
	
	public void forceOrientation() {
		log.v(this, "forceOrientation() to " + defaultOrientation);
		activity.setRequestedOrientation(defaultOrientation);
	}

	public void uiResume(SurfaceView svPreview) {		
		if (!crashReport) {
			startCamera(svPreview);							
		}
	}

	public void uiPause() {
		log.v(this, "uiPause()");		
		if (MainController.this.widgetAction) {
			deactivateWidgetAction();
		}
		stopCamera();
		isHolderReady = false;		
	}	

	public void activateWidgetAction() {
		this.widgetAction = true;
		setPreviewImage(1, 1);
	}

	public void deactivateWidgetAction() {
		this.widgetAction = false;
	}

	public void imageCaptureAction() {		
		MyThread th = new MyThread(this);		
		th.start();		
	}
	
	public class MyThread extends Thread {
		MainController controller;
		public MyThread(MainController controller) {
			this.controller = controller;			
		}
		public void run() {
			activateWidgetAction();
			while (!isCameraConfigure || bSnapShot==null) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {}
			}
			imageCapture();
			controller.sendResult();
		}				
	};
	
	public void sendResult() {
		Intent data = new Intent();
		data.putExtra("SP", ScreenPrivacy);
		activity.setResult(Activity.RESULT_OK, data);
		activity.finish();
	}
}
