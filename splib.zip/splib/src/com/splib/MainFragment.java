/* ========================================================================
 * Copyright 2013 Jimmy Halim
 * Licensed under the Creative Commons Attribution-NonCommercial 3.0 license 
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://creativecommons.org/licenses/by-nc/3.0/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
 */
package com.splib;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;

import com.jwork.spycamera.R;
import com.jwork.spycamera.utility.LogUtility;

/**
 * @author Jimmy Halim
 */
public class MainFragment extends Fragment implements Callback {
	
	private MainController controller;	
	private LogUtility log;
	private Activity activity;
	
	private SurfaceView svPreview;
	private SurfaceHolder shPreview;
	private View view;		
	
	public MainFragment() {		
		this.log = LogUtility.getInstance();
		log.v(this, "constructor()");
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		log.v(this, "onCreateView()");
		this.activity = getActivity();
		view = inflater.inflate(R.layout.fragment_main, container);		
		this.controller = new MainController(this.activity);
		initView(view);
		controller.initData(svPreview);
		return view;
	}
	
	
	@SuppressWarnings("deprecation")
	private void initView(View view) {
		log.v(this, "initView()");
		//Widgets
		this.svPreview = (SurfaceView)view.findViewById(R.id.svPreview);
		this.svPreview.setDrawingCacheQuality(100);
		this.svPreview.setDrawingCacheEnabled(true);
		this.svPreview.setZOrderOnTop(true);
		this.svPreview.setX(0);
		this.svPreview.setY(0);
		this.shPreview = this.svPreview.getHolder();
		this.shPreview.addCallback(this);
		this.shPreview.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		this.shPreview.setFormat(PixelFormat.TRANSPARENT);
	}
	
	@Override
	public void onResume() {
		log.v(this, "onResume()");
		super.onResume();
		controller.uiResume(svPreview);
	}
	
	@Override
	public void onPause() {
		log.v(this, "onPause()");
		super.onPause();
		controller.uiPause();
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		log.v(this, "surfaceChanged(format:"+format+",width:"+width+",height:"+height+")");
		controller.configureCamera(holder);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		log.v(this, "surfaceCreated()");
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		log.v(this, "surfaceDestroyed()");
	}
	
	public void imageCapture() {
		controller.imageCaptureAction();		
	}
}
