package com.splib;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;

public class SplibController {

	private boolean ScreenPrivacy;	
	private boolean SPCheckDone = false;
	public static final int SP_REQUEST = 1;
	public static final int WHAT_PRIVATE = 0;
	public static final int WHAT_PUBLIC = 1;
	
	private Activity activity;
	
	public SplibController (Activity activity) {
		this.activity = activity;
	}
	
	public void getSP(Handler handler) {
		Intent in = new Intent(activity, SpLib.class);		
		in.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);						
		activity.startActivityForResult(in, SP_REQUEST);
		
		SPMsgSender sender = new SPMsgSender(handler);
		sender.start();
	}
	
	public void setSP(boolean SP) {
		ScreenPrivacy = SP;
	}
	
	public void setSPCheckDone(boolean SPCheckDone) {
		this.SPCheckDone = SPCheckDone; 
	}			
	
	private class SPMsgSender extends Thread {
		
		Handler handler;
		
		public SPMsgSender(Handler handler) {
			this.handler = handler;
		}
		
		@Override
		public void run() {
			while (!SPCheckDone) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {}
			}
			Message msg =  new Message();
			if (ScreenPrivacy) {					
				msg.what = WHAT_PRIVATE;
			}
			else {
				msg.what = WHAT_PUBLIC;
			}
			this.handler.sendMessage(msg);			
		}
	}
}
